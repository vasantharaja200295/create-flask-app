# create_flask_app/__init__.py

from .main import main

__all__ = ['main']
